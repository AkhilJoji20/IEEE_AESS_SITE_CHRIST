import { Calendar, MapPin, Clock, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const upcomingEvents = [
  {
    title: "Radar Systems Workshop",
    date: "May 15, 2026",
    time: "10:00 AM - 4:00 PM",
    location: "Engineering Hall, Room 201",
    description: "Hands-on workshop covering radar fundamentals, signal processing, and modern applications.",
    tag: "Workshop"
  },
  {
    title: "Industry Expert Talk: Future of Avionics",
    date: "May 22, 2026",
    time: "2:00 PM - 4:00 PM",
    location: "Auditorium A",
    description: "Guest lecture by Dr. James Miller, Chief Engineer at Boeing, on emerging avionics technologies.",
    tag: "Guest Lecture"
  },
  {
    title: "Drone Design Competition",
    date: "June 5, 2026",
    time: "9:00 AM - 5:00 PM",
    location: "Innovation Center",
    description: "Annual competition challenging teams to design and build autonomous drones.",
    tag: "Competition"
  },
]

const pastEvents = [
  {
    title: "Space Systems Symposium",
    date: "March 10, 2026",
    attendees: 150,
  },
  {
    title: "PCB Design Workshop",
    date: "February 25, 2026",
    attendees: 45,
  },
  {
    title: "IEEE AESS Annual Conference",
    date: "January 15, 2026",
    attendees: 200,
  },
]

export function EventsSection() {
  return (
    <section id="events" className="py-24 relative bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="text-primary text-sm font-semibold tracking-wider uppercase">Events</span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-4 mb-6 text-balance">
            Upcoming Events
          </h2>
          <p className="text-muted-foreground">
            Stay updated with our workshops, seminars, and competitions
          </p>
        </div>

        {/* Upcoming Events */}
        <div className="grid lg:grid-cols-3 gap-6 mb-16">
          {upcomingEvents.map((event, index) => (
            <div 
              key={event.title}
              className={`glass-card rounded-2xl p-6 hover:border-primary/30 transition-all hover:-translate-y-1 ${
                index === 0 ? "lg:col-span-2 lg:row-span-2" : ""
              }`}
            >
              <div className="flex items-center gap-2 mb-4">
                <span className="px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium">
                  {event.tag}
                </span>
              </div>
              <h3 className={`font-bold text-foreground mb-3 ${index === 0 ? "text-2xl" : "text-lg"}`}>
                {event.title}
              </h3>
              <p className={`text-muted-foreground mb-4 ${index === 0 ? "text-base" : "text-sm"}`}>
                {event.description}
              </p>
              <div className="space-y-2 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Calendar size={16} className="text-primary" />
                  <span>{event.date}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock size={16} className="text-primary" />
                  <span>{event.time}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin size={16} className="text-primary" />
                  <span>{event.location}</span>
                </div>
              </div>
              {index === 0 && (
                <Button className="mt-6 bg-primary hover:bg-primary/90 text-primary-foreground">
                  Register Now
                </Button>
              )}
            </div>
          ))}
        </div>

        {/* Past Events */}
        <div className="glass-card rounded-2xl p-8">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
            <h3 className="text-xl font-bold text-foreground">Past Events</h3>
            <Button variant="ghost" className="text-primary hover:text-primary/80 gap-2">
              View All Events <ArrowRight size={16} />
            </Button>
          </div>
          <div className="grid sm:grid-cols-3 gap-4">
            {pastEvents.map((event) => (
              <div 
                key={event.title}
                className="p-4 rounded-xl bg-secondary/50 hover:bg-secondary transition-colors"
              >
                <h4 className="font-medium text-foreground mb-2">{event.title}</h4>
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>{event.date}</span>
                  <span>{event.attendees} attendees</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
