import { Button } from "@/components/ui/button"
import { ArrowRight, Play } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative min-h-screen hero-gradient flex items-center justify-center overflow-hidden">
      {/* Radar Animation Background */}
      <div className="absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none">
        <div className="relative w-[600px] h-[600px]">
          {/* Radar circles */}
          <div className="absolute inset-0 rounded-full border border-primary/30" />
          <div className="absolute inset-[15%] rounded-full border border-primary/25" />
          <div className="absolute inset-[30%] rounded-full border border-primary/20" />
          <div className="absolute inset-[45%] rounded-full border border-primary/15" />
          {/* Radar sweep */}
          <div className="absolute inset-0 radar-animation">
            <div className="absolute top-1/2 left-1/2 w-1/2 h-0.5 bg-gradient-to-r from-primary/50 to-transparent origin-left -translate-y-1/2" />
          </div>
        </div>
      </div>

      {/* Grid pattern overlay */}
      <div 
        className="absolute inset-0 opacity-5 pointer-events-none"
        style={{
          backgroundImage: `linear-gradient(oklch(0.65 0.18 240 / 0.3) 1px, transparent 1px),
                           linear-gradient(90deg, oklch(0.65 0.18 240 / 0.3) 1px, transparent 1px)`,
          backgroundSize: '50px 50px'
        }}
      />

      <div className="container mx-auto px-4 pt-24 pb-16 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 glass-card px-4 py-2 rounded-full mb-8">
            <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
            <span className="text-sm text-muted-foreground">Pioneering the Future of Aerospace</span>
          </div>
          
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6 text-balance leading-tight">
            IEEE AESS
            <span className="block text-primary">Student Chapter</span>
          </h1>
          
          <p className="text-lg text-muted-foreground mb-4 font-medium">
            Aerospace and Electronic Systems Society
          </p>
          
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto mb-10 leading-relaxed">
            Advancing innovation in radar systems, avionics, defense electronics, and space systems. 
            Join a community of aspiring engineers and researchers shaping the future of aerospace technology.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2 px-8">
              Join Us
              <ArrowRight size={18} />
            </Button>
            <Button size="lg" variant="outline" className="border-border hover:bg-secondary gap-2">
              <Play size={18} />
              View Events
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16 pt-16 border-t border-border/50">
            {[
              { value: "50+", label: "Active Members" },
              { value: "25+", label: "Events Hosted" },
              { value: "10+", label: "Projects" },
              { value: "5+", label: "Industry Partners" },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2">
        <div className="w-6 h-10 rounded-full border-2 border-muted-foreground/30 flex justify-center pt-2">
          <div className="w-1 h-2 bg-muted-foreground/50 rounded-full animate-bounce" />
        </div>
      </div>
    </section>
  )
}
