"use client"

import { useState } from "react"
import { X } from "lucide-react"

const galleryImages = [
  { id: 1, title: "Radar Workshop 2026", category: "Workshop" },
  { id: 2, title: "Annual Conference", category: "Conference" },
  { id: 3, title: "Drone Competition", category: "Competition" },
  { id: 4, title: "Industry Visit", category: "Field Trip" },
  { id: 5, title: "Hackathon Winners", category: "Competition" },
  { id: 6, title: "Guest Lecture Series", category: "Seminar" },
  { id: 7, title: "Lab Session", category: "Workshop" },
  { id: 8, title: "Team Building", category: "Social" },
]

export function GallerySection() {
  const [selectedImage, setSelectedImage] = useState<number | null>(null)

  return (
    <section id="gallery" className="py-24 relative bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="text-primary text-sm font-semibold tracking-wider uppercase">Gallery</span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-4 mb-6 text-balance">
            Moments Captured
          </h2>
          <p className="text-muted-foreground">
            Highlights from our workshops, events, and activities
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {galleryImages.map((image, index) => (
            <button
              key={image.id}
              onClick={() => setSelectedImage(image.id)}
              className={`relative group overflow-hidden rounded-xl aspect-square bg-secondary hover:ring-2 hover:ring-primary/50 transition-all ${
                index === 0 ? "md:col-span-2 md:row-span-2" : ""
              }`}
            >
              {/* Placeholder pattern */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center p-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-2">
                    <span className="text-primary text-xl font-bold">{image.id}</span>
                  </div>
                  <span className="text-muted-foreground text-sm">{image.category}</span>
                </div>
              </div>
              
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                <div className="text-left">
                  <p className="text-foreground font-medium text-sm">{image.title}</p>
                  <p className="text-muted-foreground text-xs">{image.category}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {selectedImage && (
        <div 
          className="fixed inset-0 z-50 bg-background/95 flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <button 
            className="absolute top-4 right-4 text-foreground hover:text-primary transition-colors"
            onClick={() => setSelectedImage(null)}
          >
            <X size={32} />
          </button>
          <div className="max-w-4xl w-full aspect-video bg-secondary rounded-2xl flex items-center justify-center">
            <div className="text-center">
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <span className="text-primary text-3xl font-bold">{selectedImage}</span>
              </div>
              <p className="text-foreground font-medium">
                {galleryImages.find(img => img.id === selectedImage)?.title}
              </p>
              <p className="text-muted-foreground text-sm">
                {galleryImages.find(img => img.id === selectedImage)?.category}
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  )
}
