import { Linkedin, Mail, User } from "lucide-react"

const teamMembers = [
  {
    name: "Dr. Sarah Mitchell",
    role: "Faculty Advisor",
    department: "Aerospace Engineering",
    image: null,
  },
  {
    name: "Alex Johnson",
    role: "Chair",
    department: "Electronics & Communication",
    image: null,
  },
  {
    name: "Priya Sharma",
    role: "Vice Chair",
    department: "Aerospace Engineering",
    image: null,
  },
  {
    name: "Michael Chen",
    role: "Secretary",
    department: "Computer Science",
    image: null,
  },
]

const coreTeam = [
  { name: "Emily Davis", role: "Technical Lead" },
  { name: "James Wilson", role: "Events Coordinator" },
  { name: "Aisha Patel", role: "Marketing Head" },
  { name: "David Kim", role: "Treasurer" },
  { name: "Sofia Garcia", role: "Outreach Lead" },
  { name: "Ryan Thompson", role: "Web Developer" },
]

export function TeamSection() {
  return (
    <section id="team" className="py-24 relative">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="text-primary text-sm font-semibold tracking-wider uppercase">Our Team</span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-4 mb-6 text-balance">
            Meet the Leaders
          </h2>
          <p className="text-muted-foreground">
            Driven by passion and dedicated to advancing aerospace innovation
          </p>
        </div>

        {/* Executive Team */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {teamMembers.map((member) => (
            <div 
              key={member.name}
              className="glass-card rounded-2xl p-6 text-center group hover:border-primary/30 transition-all hover:-translate-y-1"
            >
              <div className="w-24 h-24 rounded-full bg-secondary flex items-center justify-center mx-auto mb-4 overflow-hidden">
                {member.image ? (
                  <img src={member.image} alt={member.name} className="w-full h-full object-cover" />
                ) : (
                  <User className="w-10 h-10 text-muted-foreground" />
                )}
              </div>
              <h3 className="font-semibold text-foreground mb-1">{member.name}</h3>
              <p className="text-primary text-sm font-medium mb-1">{member.role}</p>
              <p className="text-muted-foreground text-xs mb-4">{member.department}</p>
              <div className="flex justify-center gap-3 opacity-0 group-hover:opacity-100 transition-opacity">
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  <Linkedin size={18} />
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  <Mail size={18} />
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Core Team */}
        <div className="text-center mb-8">
          <h3 className="text-2xl font-bold text-foreground">Core Team</h3>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {coreTeam.map((member) => (
            <div 
              key={member.name}
              className="glass-card rounded-xl p-4 text-center hover:border-primary/30 transition-colors"
            >
              <div className="w-14 h-14 rounded-full bg-secondary flex items-center justify-center mx-auto mb-3">
                <User className="w-6 h-6 text-muted-foreground" />
              </div>
              <h4 className="font-medium text-foreground text-sm mb-1">{member.name}</h4>
              <p className="text-muted-foreground text-xs">{member.role}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
