import { Radar, Plane, Cpu, Brain, Satellite, Radio } from "lucide-react"

const projects = [
  {
    icon: Radar,
    title: "Radar Systems",
    description: "Development of compact radar modules for object detection and tracking applications.",
    status: "Active",
    members: 8,
  },
  {
    icon: Plane,
    title: "Avionics",
    description: "Building flight control systems and cockpit display interfaces for small aircraft.",
    status: "Active",
    members: 6,
  },
  {
    icon: Cpu,
    title: "Embedded Systems",
    description: "Designing embedded solutions for aerospace applications using FPGA and microcontrollers.",
    status: "Active",
    members: 10,
  },
  {
    icon: Brain,
    title: "AI in Aerospace",
    description: "Machine learning models for predictive maintenance and autonomous navigation.",
    status: "Research",
    members: 5,
  },
  {
    icon: Satellite,
    title: "CubeSat Mission",
    description: "Student-led satellite project for Earth observation and communication experiments.",
    status: "Planning",
    members: 12,
  },
  {
    icon: Radio,
    title: "RF Communication",
    description: "Developing software-defined radio systems for satellite ground station operations.",
    status: "Active",
    members: 4,
  },
]

export function ProjectsSection() {
  return (
    <section id="projects" className="py-24 relative">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="text-primary text-sm font-semibold tracking-wider uppercase">Projects</span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-4 mb-6 text-balance">
            Research & Projects
          </h2>
          <p className="text-muted-foreground">
            Explore our ongoing projects pushing the boundaries of aerospace technology
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project) => (
            <div 
              key={project.title}
              className="glass-card rounded-2xl p-6 hover:border-primary/30 transition-all hover:-translate-y-1 group"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <project.icon className="w-6 h-6 text-primary" />
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                  project.status === "Active" 
                    ? "bg-green-500/10 text-green-400"
                    : project.status === "Research"
                    ? "bg-accent/10 text-accent"
                    : "bg-yellow-500/10 text-yellow-400"
                }`}>
                  {project.status}
                </span>
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2 group-hover:text-primary transition-colors">
                {project.title}
              </h3>
              <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                {project.description}
              </p>
              <div className="flex items-center justify-between pt-4 border-t border-border">
                <span className="text-sm text-muted-foreground">
                  {project.members} members
                </span>
                <a 
                  href="#"
                  className="text-primary text-sm font-medium hover:underline"
                >
                  Learn more
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
