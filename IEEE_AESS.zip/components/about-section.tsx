import { Target, Eye, Users, Award, BookOpen, Rocket } from "lucide-react"

const benefits = [
  {
    icon: BookOpen,
    title: "Technical Knowledge",
    description: "Access to workshops, seminars, and hands-on projects in aerospace systems"
  },
  {
    icon: Users,
    title: "Networking",
    description: "Connect with industry professionals, researchers, and fellow enthusiasts"
  },
  {
    icon: Award,
    title: "Recognition",
    description: "Participate in competitions and earn certifications recognized globally"
  },
  {
    icon: Rocket,
    title: "Career Growth",
    description: "Internship opportunities and career guidance from industry experts"
  }
]

export function AboutSection() {
  return (
    <section id="about" className="py-24 relative">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="text-primary text-sm font-semibold tracking-wider uppercase">About Us</span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-4 mb-6 text-balance">
            What is IEEE AESS?
          </h2>
          <p className="text-muted-foreground leading-relaxed">
            The IEEE Aerospace and Electronic Systems Society (AESS) is a professional organization 
            dedicated to the advancement of the science and technology of aerospace and electronic systems. 
            Our student chapter brings this mission to campus, fostering innovation and learning among 
            the next generation of engineers.
          </p>
        </div>

        {/* Mission & Vision */}
        <div className="grid md:grid-cols-2 gap-6 mb-16">
          <div className="glass-card rounded-2xl p-8 hover:border-primary/30 transition-colors">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-6">
              <Target className="w-6 h-6 text-primary" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-4">Our Mission</h3>
            <p className="text-muted-foreground leading-relaxed">
              To provide students with opportunities to explore aerospace and electronic systems 
              through hands-on projects, workshops, and industry connections. We aim to bridge the 
              gap between academic learning and real-world applications.
            </p>
          </div>

          <div className="glass-card rounded-2xl p-8 hover:border-primary/30 transition-colors">
            <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-6">
              <Eye className="w-6 h-6 text-accent" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-4">Our Vision</h3>
            <p className="text-muted-foreground leading-relaxed">
              To become a leading student chapter that nurtures future aerospace engineers and 
              researchers, creating a collaborative environment where innovation thrives and 
              students are prepared for careers in the aerospace industry.
            </p>
          </div>
        </div>

        {/* Benefits */}
        <div className="text-center mb-12">
          <h3 className="text-2xl font-bold text-foreground mb-4">Benefits of Joining</h3>
          <p className="text-muted-foreground">Unlock opportunities that accelerate your career</p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {benefits.map((benefit) => (
            <div 
              key={benefit.title}
              className="glass-card rounded-xl p-6 text-center hover:border-primary/30 transition-all hover:-translate-y-1"
            >
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <benefit.icon className="w-6 h-6 text-primary" />
              </div>
              <h4 className="font-semibold text-foreground mb-2">{benefit.title}</h4>
              <p className="text-sm text-muted-foreground">{benefit.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
