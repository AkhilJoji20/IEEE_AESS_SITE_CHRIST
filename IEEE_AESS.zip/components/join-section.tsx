import { Button } from "@/components/ui/button"
import { ArrowRight, CheckCircle } from "lucide-react"

const benefits = [
  "Access to exclusive IEEE resources and publications",
  "Networking opportunities with industry professionals",
  "Discounts on conferences and workshops",
  "Leadership and skill development opportunities",
  "Project collaboration with peers",
  "Certificate and recognition programs",
]

export function JoinSection() {
  return (
    <section id="join" className="py-24 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 hero-gradient opacity-50" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="glass-card rounded-3xl p-8 md:p-12 lg:p-16 max-w-5xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 mb-8">
            <span className="text-primary text-sm font-medium">Become a Member</span>
          </div>
          
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6 text-balance">
            Join IEEE AESS Student Chapter
          </h2>
          
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto mb-10 leading-relaxed">
            Be part of a global community advancing aerospace and electronic systems. 
            Unlock opportunities, gain knowledge, and shape the future of technology.
          </p>

          <div className="grid sm:grid-cols-2 gap-4 max-w-2xl mx-auto mb-10 text-left">
            {benefits.map((benefit) => (
              <div key={benefit} className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                <span className="text-muted-foreground text-sm">{benefit}</span>
              </div>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2 px-8">
              Join IEEE Now
              <ArrowRight size={18} />
            </Button>
            <Button size="lg" variant="outline" className="border-border hover:bg-secondary">
              Learn More About IEEE
            </Button>
          </div>

          <p className="text-muted-foreground text-sm mt-8">
            Already an IEEE member?{" "}
            <a href="#" className="text-primary hover:underline">
              Add AESS membership
            </a>
          </p>
        </div>
      </div>
    </section>
  )
}
